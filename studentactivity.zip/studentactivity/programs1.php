<!DOCTYPE html>
<html>
<head>
<title></title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel = "stylesheet" type = "text/css" href = "css/style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <link href = "https://fonts.googleapis.com/css?family=Josefin+Sans&display=swap" rel = "stylesheet">
  
</head>
<body>

<?php include 'menu1.php'; ?>

<section class = "my-3">
    <div class = "py-4">
        <h2 class = "text-center">Our Programs</h2>
    </div>
<p><h3 class = "text-center">Industrial Exposure bridges the gap between thoeretical training and practical learning.

As it helps the student to apply their technical knowledge in real-life enviroment. Industrial exposure provides the students with the opportunity for learning experiences outside the classroom environment and also to work with industrial professionals.</h3></p>
    <div class = "container-fluid">
        <div class = "row">
          <div class = "col-lg-4 col-md-4 col-12">          
   <div class="card">
  <img class="card-img-top" src="images/dev.jpg" alt="Dev image">
  <div class="card-body">
  <h4 class="card-title">Dev Technologies</h4>
    <p class="card-text">Visited Date: 5 September,2018</p>
    <p class="card-text">Location: Ahmedabad</p>
    <a href="dev1.php" class="btn btn-primary">More Info</a>
  </div>
</div>     
</div>

<div class = "col-lg-4 col-md-4 col-12">          
   <div class="card">
  <img class="card-img-top" src="images/green.jpg" alt="card image">
  <div class="card-body">
    <h4 class="card-title">Green Field Control System Pvt. Ltd.</h4>
    <p class="card-text">Visited Date: 5 September,2018</p>
    <p class="card-text">Location: Ahmedabad</p>
    <a href="green1.php" class="btn btn-primary">More Info</a>
  </div>
</div>     
</div>

<div class = "col-lg-4 col-md-4 col-12">          
   <div class="card">
  <img class="card-img-top" src="images/isro.jpg" alt="isro image">
  <div class="card-body">
    <h4 class="card-title">ISRO</h4>
    <p class="card-text">Visited Date: 12 April, 2019</p>
    <p class="card-text">Location: Ahmedabad</p>
    <a href="isro1.php" class="btn btn-primary">More Info</a>
  </div>
</div>     
</div>
</div>
</div>
</section>

<footer>
<p class = "p-3 bg-dark text-white text-center">@studentactivityproduction</p>
</footer>

</body>
</html>
