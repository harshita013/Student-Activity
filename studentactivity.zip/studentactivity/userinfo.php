<?php

$conn = mysqli_connect('localhost','root');

if($conn)
{
    echo "Connection Successfully";
}
else{
    echo "No Connection";
}

mysqli_select_db($conn, 'studentuserdata');

$user = $_POST['user'];
$email = $_POST['email'];
$mobile = $_POST['mobile'];
$comment = $_POST['comment'];

$query = "insert into userinfodata (user, email, mobile, comment) values ('$user', '$email', '$mobile', '$comment')";

echo "$query";
mysqli_query($conn, $query);

header('location:index.php');

?>