<!DOCTYPE html>
<html>
<head>
<title></title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel = "stylesheet" type = "text/css" href = "css/style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <link href = "https://fonts.googleapis.com/css?family=Josefin+Sans&display=swap" rel = "stylesheet">
  
</head>
<body>

<?php include 'menu.php'; ?>
<section class = "my-3">
<div class = "py-4">
    <h1 class = "text-center">Dev Technologies</h1>
</div>
<div class = "container-fluid">
           <div class = "row">
           <div class = "col-lg-6 col-md-6 col-12">
             <img src="images/dev.jpg" class = "img-fluid aboutimg">
           </div>
           <div class = "col-lg-6 col-md-6 col-12">
             <h3 class = "display-5">About</h3>
             <p class = "py-2">
             <h5>
             
            Dev Information Technology Ltd. works together with its clients across the globe to empower their business with the right mix of information technologies, innovation and digital transformation. Right from advisory to execution backed by the expert applications and infrastucture management; we optimize your IT into a strategic asset.</p>


            <p>
            Address:  Block 1, Janumang Co-Operative Housing Society Ltd, Janpath Apartment, Behind Sahjanand College, Ambawadi, Ahmedabad, Gujarat 380015</p>

           <p> Website: https://www.devitpl.com/</p>
            </h5>
            
</div>
</div>
</section>

<footer>
<p class = "p-3 bg-dark text-white text-center">@studentactivityproduction</p>
</footer>


</body>
</html>
