<!DOCTYPE html>
<html>
<head>
<title></title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel = "stylesheet" type = "text/css" href = "css/style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <link href = "https://fonts.googleapis.com/css?family=Josefin+Sans&display=swap" rel = "stylesheet">
  
</head>
<body>

<?php include 'menu1.php'; ?>

<section class = "my-3">
<div class = "py-4">
    <h1 class = "text-center">Indian Space Research Organisation (ISRO)</h1>
</div>
<div class = "container-fluid">
           <div class = "row">
           <div class = "col-lg-6 col-md-6 col-12">
             <img src="images/isro.jpg" class = "img-fluid aboutimg">
           </div>
           <div class = "col-lg-6 col-md-6 col-12">
             <h3 class = "display-5">About</h3>
             <p class = "py-2">
             <h5>
             
             Space Applications Centre (SAC) at Ahmedabad is spread across two campuses having multi-disciplinary activities. The core competence of the Centre lies in  development of space borne and air borne instruments / payloads and their applications for national development and societal benefits. These applications are in diverse areas and primarily meet the communication, navigation and remote sensing needs of the country. Besides these, the Centre also contributed significantly in scientific and planetary missions of ISRO like Chandrayaan-1, Mars Orbiter Mission, etc. The communication transponders developed at this Centre for Indian National Satellite (INSAT) and Geo Synchronous Satellite (GSAT) series of satellites are used by government and private sector for VSAT, DTH, Internet, broadcasting, telephones etc.</p>
            <p>
            Main Engine and Stage Test Facility at IPRC This centre also designs and develops the optical and microware sensors for the satellites, signal and image processing software, GIS software and many applications for Earth Observation (EO) programme of ISRO. These applications are in diverse areas of Geosciences, Agriculture, Environment and Climate Change, Physical Oceanography, Biological Oceanography, Atmosphere, Cryosphere, Hydrosphere, etc. The facilities at SAC include highly sophisticated payload integration laboratories, electronic and mechanical fabrication facilities, environmental test facilities, systems reliability / assurance group, image processing and analysis facilities, project management support group and a well-stocked library. SAC has active collaborations with industry, academia, national and international institutes for research and development. The Centre also conducts nine-month post graduate diploma courses for students from the Asia Pacific region under the aegis of the Centre for Space Science and Technology Education (CSSTE-AP) in satellite meteorology and communication.</p>


            <p>
            Address: Space Applications Centre (SAC) Campus, Jodhpur Tekra, Ambawadi Vistar, Ahmedabad, Gujarat 380015</p>

           <p> Website: https://www.isro.gov.in </p>
            </h5>
            
</div>
</div>
</div>
</section>

<footer>
<p class = "p-3 bg-dark text-white text-center">@studentactivityproduction</p>
</footer>


</body>
</html>
