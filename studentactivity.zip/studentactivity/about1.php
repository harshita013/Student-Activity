<!DOCTYPE html>
<html>
<head>
<title></title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel = "stylesheet" type = "text/css" href = "css/style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <link href = "https://fonts.googleapis.com/css?family=Josefin+Sans&display=swap" rel = "stylesheet">
  
</head>
<body>

<?php include 'menu1.php'; ?>

  
<section class = "my-3">

<div class = "py-4">
    <h1 class = "text-center">About Us</h1>
</div>
<div class = "container-fluid">
           <div class = "row">
           <div class = "col-lg-6 col-md-6 col-12">
             <img src="images/2.jpg" class = "img-fluid aboutimg">
           </div>
           <div class = "col-lg-6 col-md-6 col-12">
             <p class = "py-3">
             <h5>
             Education is the process of facilitating learning, or the acquisition of knowledge, skills, values, beliefs, and habits. Educational methods include teaching, training, storytelling, discussion and directed research.</p>

            <p>
             Rule 1: People learn by doing. Provide opportunities to apply new knowledge and skills by practicing in as realistic a setting as possible. Activities that involve thoughtful responses, decision-making and solving problems encourage active learning and also promote higher order thinking.</p>

            <p>
            Rule 2: Learning is social. Create ways for participants to learn from each other, to interact, discuss and exchange information. Encourage them to join relevant social networks to learn from a diverse group of practitioners. Promote the development of a personal learning environment that will keep participants connected and up-to-date. Relevant social interaction deepens learning.
            </h5>
            </p>           
</div>
</div>
</section>

<footer>
<p class = "p-3 bg-dark text-white text-center">@studentactivityproduction</p>
</footer>

</body>
</html>
