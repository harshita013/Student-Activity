<!DOCTYPE html>
<html>
<head>
<title></title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel = "stylesheet" type = "text/css" href = "css/style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <link href = "https://fonts.googleapis.com/css?family=Josefin+Sans&display=swap" rel = "stylesheet">
  
</head>
<body>

<?php include 'menu1.php'; ?>

  <div id="demo" class="carousel slide" data-ride="carousel">
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ul>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/hats.jpg" alt="hats image" width="1100" height="500">
      <div class="carousel-caption">
        <h3></h3>
        <p><h3>“Education is the most powerful weapon which you can use to change the world.” 
                                                                      -Nelson Mandela</h3>
        </p>
      </div>   
    </div>

    <div class="carousel-item">
      <img src="images/1.jpg" alt="1" width="1100" height="500">
      <div class="carousel-caption">
        <h3></h3>
        <p><h3>"Do unto others as you would have them do unto you"  
                                              -Jesus Christ </h3>
        </p>
      </div>   
    </div>

    <div class="carousel-item">
      <img src="images/activity.jpg" alt="2" width="1100" height="500">
      <div class="carousel-caption">
        <h3></h3>
        <p><h3>"Lack of activity destroys the good condition of every human being, while movement and methodical physical exercise save it and preserve it."
                                                                         -Plato </h3></p>
      </div>   
    </div>
  </div>
  <a class="carousel-control-prev" href="#" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>

<section class = "my-3">
<div class = "py-4">
    <h1 class = "text-center">About Us</h1>
</div>
<div class = "container-fluid">
           <div class = "row">
           <div class = "col-lg-6 col-md-6 col-12">
             <img src="images/2.jpg" class = "img-fluid aboutimg">
           </div>
           <div class = "col-lg-6 col-md-6 col-12">
             <p class = "py-3">
             Education is the process of facilitating learning, or the acquisition of knowledge, skills, values, beliefs, and habits. Educational methods include teaching, training, storytelling, discussion and directed research.
            </p>
            <a href = "about1.php" class = "btn btn-success"> Check More</a>
</div>
</div>
</section>

<section class = "my-3">
    <div class = "py-4">
        <h2 class = "text-center">Our Programs</h2>
    </div>

    <div class = "container-fluid">
        <div class = "row">
        <div class = "col-lg-4 col-md-4 col-12">          
   <div class="card">
  <img class="card-img-top" src="images/dev.jpg" alt="Dev image">
  <div class="card-body">
    <h4 class="card-title">Dev Technologies</h4>
    <p class="card-text">Visited Date: 5 September,2018</p>
    <p class="card-text">Location: Ahmedabad</p>
    <a href="dev1.php" class="btn btn-primary">More Info</a>
  </div>
</div>     
</div>

<div class = "col-lg-4 col-md-4 col-12">          
   <div class="card">
  <img class="card-img-top" src="images/green.jpg" alt="Card image">
  <div class="card-body">
  <h4 class="card-title">Green Field Control System Pvt. Ltd.</h4>
    <p class="card-text">Visited Date: 5 September,2018</p>
    <p class="card-text">Location: Ahmedabad</p>
    <a href="green1.php" class="btn btn-primary">More Info</a>
  </div>
</div>     
</div>

<div class = "col-lg-4 col-md-4 col-12">          
   <div class="card">
  <img class="card-img-top" src="images/isro.jpg" alt="isro image">
  <div class="card-body">
    <h4 class="card-title">ISRO</h4>
    <p class="card-text">Visited Date: 12 April, 2019</p>
    <p class="card-text">Location: Ahmedabad</p>
    <a href="isro1.php" class="btn btn-primary">More Info</a>
  </div>
</div>     
</div>
<a href = "programs1.php" class = "btn btn-success"> Check More</a>
</div>
</div>
</section>

<section class = "my-5">
    <div class = "py-4">
        <h2 class = "text-center">Gallery</h2>
    </div>

    <div class = "container-fluid">
        <div class = "row">
            <div class = "col-lg-4 col-md-4 col-12">
                <img src = "images/a.jpg" class = "img-fluid pb-4">
            </div>

            <div class = "col-lg-4 col-md-4 col-12">
                <img src = "images/b.jpg" class = "img-fluid pb-4">
            </div>

            <div class = "col-lg-4 col-md-4 col-12">
                <img src = "images/c.jpg" class = "img-fluid pb-4">
            </div>

            <div class = "col-lg-4 col-md-4 col-12">
                <img src = "images/d.jpg" class = "img-fluid pb-4">
            </div>

            <div class = "col-lg-4 col-md-4 col-12">
                <img src = "images/e.jpg" class = "img-fluid pb-4">
            </div>

            <div class = "col-lg-4 col-md-4 col-12">
                <img src = "images/f.jpg" class = "img-fluid pb-4">
            </div>
        </div>
    </div>
</section>

<section class = "my-5">
    <div class = "py-4">
        <h2 class = "text-center">Contact Us</h2>
    </div>

    <div class = "w-50 m-auto">
        <form action = "userinfo.php" method = "post">
            <div class = "form-group">
                <label>Username</label>
                <input type = "text" name = "user" autocomplete = "off" class = "form-control">
            </div>

            <div class = "form-group">
                <label>Email</label>
                <input type = "text" name = "email" autocomplete = "off" class = "form-control">
            </div>

            <div class = "form-group">
                <label>Mobile No</label>
                <input type = "text" name = "mobile" autocomplete = "off" class = "form-control">
            </div>

            <div class = "form-group">
                <label>Comments</label>
                <textarea class = "form-control" name = "comment">
                </textarea>
            </div>

            <button type="submit" class="btn btn-success">Submit</button>

        </form>
    </div>
</section>

<footer>
<p class = "p-3 bg-dark text-white text-center">@studentactivityproduction</p>
</footer>




<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

</body>
</html>